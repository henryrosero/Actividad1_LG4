from src.config.db import DB

class ProductosModel():
    def traerTodos(self):
        cursor = DB.cursor()

        cursor.execute('select * from productos')

        productos = cursor.fetchall()
        
        cursor.close()

        return productos
    
    def crear(self, nombre, descripcion, pventa, pcompra, estado):
        cursor = DB.cursor()

        cursor.execute('insert into productos(nombre, descripcion, precio_de_venta, precio_de_compra, estado) values(?,?,?,?,?)', (nombre, descripcion, pventa, pcompra, estado,))

        cursor.close()


    def eliminar(self, nombre):
        cursor = DB.cursor()

        cursor.execute('delete from productos WHERE nombre = ?', (nombre,))

        cursor.close()